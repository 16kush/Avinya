/** @format */

import React from "react";

const SumbitButton = (props) => (
	<button
		className={props.className}
		type='sumbit'>
		{props.Label}
	</button>
);

export default SumbitButton;
