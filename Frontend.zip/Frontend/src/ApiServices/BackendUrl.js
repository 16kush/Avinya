/** @format */

const Url = "http://localhost:8080/";

export default Url;